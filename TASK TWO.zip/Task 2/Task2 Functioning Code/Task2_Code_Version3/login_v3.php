<!DOCTYPE php>
<html lang="en">
<head>

	<?php
		//opens session to stop errors
		session_start();

	?>

	<!-- link to stylesheet -->
	<link rel="stylesheet" href="stylesheet_v3.css">
	
	<h1 class="name">Health Advice Group</h1>
	
	<!-- tab title -->
	<title>Health Advice Group | Login</title>
</head>
<body style="height:100vh">
	<div class="navbar">
		<ul>
			<li><a href="dashboard_v3.html">Home</a></li>
			<li><a href="location_v3.php">Location</a></li>
			<li><a href="advice_v3.html">Advice</a></li>
			<li><a href="account_v3.html">Account</a></li>
			<li><a href="login_v3.php" class="active">Login</a></li>
		</ul>
	</div>
	
	<!-- login form to allow users to enter their information -->
	<div class="login-form">
		<h2> LOGIN </h2>
		<form action="login_v3.php" method="post">
			<input class="input" type="text" placeholder="Email Address" name="email" required></input> <br>
			<input class="input" type="text" placeholder="Password" name="password" required></input> <br>
			<input class="submit" type="submit" name="submit" value="Login"></input>
		</form>
		<!-- lets user redirect to register page to create an account -->
		<p> Not a user? <a href="register_v3.php">Sign Up</a> </p>
	</div>
	
	<?php
	//connecting to database
	require_once("db_connect_v3.php");

	$response = "";

	//storing entered data as variables
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$email = $_POST['email'];
		$password = $_POST['password'];	
		
		//Once account details have been taken, uses this query that the correct email and password
		//has been entered, and that the details correspond to one another.
		if($result = $conn->query("SELECT * FROM account WHERE email = '$email' AND password = '$password';")){
			if($row = $result->fetch_assoc()){
				$_SESSION['user'] = $row;
				$response = "Successfully logged in as ".$_SESSION['user']['name'];
				
			}
			
		}
	
	}
	
	if(in_array('user', $_SESSION)){
			echo "Logged in as ".$_SESSION['user']['name'];
			$name = $_SESSION['user']['name'];
			
	}

	?>

	<div class="message" style="text-align:center; color:teal;">
		<?php echo $response;?>

	</div>

</body>

</html>