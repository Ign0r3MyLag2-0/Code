<html>
<head>

	<?php
	//opens session
		session_start();
		echo $_SESSION['user']['name'];
	?>

	<!-- link to stylesheet -->
	<link rel="stylesheet" href="stylesheet_v3.css">
	
	<h1 class="name">Health Advice Group</h1>
	
	<!-- tab title -->
	<title>Health Advice Group | Register</title>
</head>
<body style="height:100vh">
	<div class="navbar">
		<ul>
			<li><a href="dashboard_v3.html">Home</a></li>
			<li><a href="location_v3.php">Location</a></li>
			<li><a href="advice_v3.html">Advice</a></li>
			<li><a href="account_v3.html">Account</a></li>
			<li><a href="login_v3.php" class="active">Login</a></li>
		</ul>
	</div>
	
	<!-- register form to let user enter their details and create an account -->
	<div class="login-form">
		<h2> REGISTER </h2>
		<form action="register_v2.php"method="POST">
			<input class="input" type="text" placeholder="Email Address" name="email" required></input><label style="color:red;">*</label> <br>
			<input class="input" type="text" placeholder="First Name" name="name" required></input><label style="color:red;">*</label> <br>
			<input class="input" type="text" placeholder="Password" name="password" required></input><label style="color:red;">*</label> <br>
			<input class="input" type="text" placeholder="Confirm Password" name="c_password"></input> <br>
			<input class="submit" type="submit" name="submit" value="Register"></input>
		</form>
		
		<!-- redirects to the login page if user wants to sign in -->
		<p> Already have an account? <a href="login_v3.php">Sign In</a> </p>
	</div>
	

	<?php
	
	//Database connection
	require_once("db_connect_v3.php");
	
	//Verifying that database is connected (pulls all data from account table)
	$sql = "SELECT * FROM account";
	$output = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($output) > 0){
		while($row = mysqli_fetch_assoc($output)){
			echo "id: ".$row["account_id"]." name: ".$row["name"]." email: ".$row["email"]." password: ".$row["password"];
		}
	
	}
	//if empty, say zero results
	else{
		echo "0 results";
	}

	//initialising variables
	$password = $email = $name = "";
	$invalid = false;
	$password_number_err = $password_length_err = $password_capital_err = "";
	$email_err = $name_err = "";


	//storing entered details as variables
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$name = $_POST['name'];
		$password = $_POST['password'];	
		$email = $_POST['email'];

		$length = strlen($password);

		//Validation Rules

		//Email validation
		//Checks for '@', and valid domain
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$email_err = "Email must include '@' symbol and valid domain, such as '.com'";
			$invalid = true;

		}
		//Password Validation
		//Length Check
		if($length <9){
			$password_length_err = "Password must be a minimum of 10 characters.";
			$invalid = true;
		}
		//Presence Check (numbers)
		if(!preg_match('#[0-9]+#', $password)){
			$password_number_err = "Password must include numbers and letters.";
			$invalid = true;
		}
		//Presence Check (capital letter)
		if(!preg_match('#[A-Z]+#', $password)){
			$password_capital_err = "Password must include a capital letter.";
			$invalid = true;

		}
		//Name Validation
		//Cannot contain numbers
		if(!preg_match("/^[a-zA-Z]*$/", $name)){
			$name_err = "Name can only contain letters.";
			$invalid = true;

		}




	}

	//creating the query to insert a new account into the database
	$sql = "INSERT INTO account (email,name,password) VALUES ('$email', '$name', '$password')";

	//running the query once the submit button is pressed
	if(isset($_POST['submit']) && $invalid===false){
		mysqli_query($conn, $sql);
		header("location:register_v2.php");
	}
	
	
	//close the connection
	mysqli_close($conn);
	?>
	
	
	<div style="color:red; text-align:center;">
		<?php echo $password_length_err; ?> <br>
		<?php echo $password_number_err; ?> <br>
		<?php echo $password_capital_err; ?> <br>
		<?php echo $email_err; ?> <br>
		<?php echo $name_err; ?>
	</div>


</body>

</html>