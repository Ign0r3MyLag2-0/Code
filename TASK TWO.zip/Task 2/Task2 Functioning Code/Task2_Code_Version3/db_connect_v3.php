<!DOCTYPE php>
<html lang="en">
	<?php
	
	
	//connecting to database
	$servername = "localhost";
	$db_username = "admin";
	$db_password = "Mountain21";
	$db_name = "task2_db_v2";
	
	//sets $conn by default to the account details and login function for the database
	$conn = mysqli_connect($servername, $db_username, $db_password, $db_name);
	
	//error message upon failed connection
	if(!$conn){
		die("failed to connect: ".mysqli_connect_error());
	}
	
	
	?>


</html>