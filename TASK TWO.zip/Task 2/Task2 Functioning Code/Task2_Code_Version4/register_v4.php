<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php
	//opens session
		session_start();
	?>

	<!-- link to stylesheet -->
	<link rel="stylesheet" href="stylesheet_v4.css">
	
	<h1 class="name">Health Advice Group</h1>
	
	<!-- tab title -->
	<title>Health Advice Group | Register</title>
</head>
<!-- id of 'mode' for planned light and dark modes -->
<body style="height:100vh" id="Mode">
	<nav class="navbar">
		<ul>
			<li><a href="dashboard_v4.html">Home</a></li>
			<li><a href="weather_v4.php">Weather</a></li>
			<li><a href="advice_v4.html">Advice</a></li>
			<li><a href="account_v4.php">Account</a></li>
			<li><a href="login_v4.php" class="active">Login</a></li>
		</ul>
	</nav>
	
	<!-- register form to let user enter their details and create an account -->
	<main class="login-form">
		<h2> REGISTER </h2>
		<form action="register_v4.php"method="POST">
			<input class="input" type="text" placeholder="Email Address" name="email" required></input><label style="color:red;">*</label> <br>
			<input class="input" type="text" placeholder="First Name" name="name" required></input><label style="color:red;">*</label> <br>
			<input class="input" type="text" placeholder="Password" name="password" required></input><label style="color:red;">*</label> <br>
			<input class="submit" type="submit" name="submit" value="Register"></input>
		</form>
		
		<!-- redirects to the login page if user wants to sign in -->
		<p> Already have an account? <a href="login_v4.php">Sign In</a> </p>
		<p> By registering with us you agree to our <a href="#terms.txt"> Terms and Conditions.</a></p>
	</main>

	
	

	<?php
	
	//Database connection
	require_once("db_connect_v4.php");

	//testing inputs to prevent SQL injection
	function test_inputs($input){
		global $conn;
		$input = trim($input);
		$input = stripslashes($input);
		$input = htmlspecialchars($input);
		//any remaining special characters are not considered as part of a query
		return mysqli_real_escape_string($conn, $input);
	}



	//initialising variables
	$password = $email = $name = "";
	$invalid = false;
	$password_number_err = $password_length_err = $password_capital_err = "";
	$email_err = $name_err = "";


	//storing entered details as variables
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		$name = test_inputs($_POST['name']);
		$password = test_inputs($_POST['password']);	
		$email = test_inputs($_POST['email']);
		

		$length = strlen($password);

		//Validation Rules

		//Email validation
		//Checks for '@', and valid domain
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$email_err = "Email must include '@' symbol and valid domain, such as '.com'";
			$invalid = true;

		}
		//Password Validation
		//Length Check
		if($length <9){
			$password_length_err = "Password must be a minimum of 10 characters.";
			$invalid = true;
		}
		//Presence Check (numbers)
		if(!preg_match('#[0-9]+#', $password)){
			$password_number_err = "Password must include numbers and letters.";
			$invalid = true;
		}
		//Presence Check (capital letter)
		if(!preg_match('#[A-Z]+#', $password)){
			$password_capital_err = "Password must include a capital letter.";
			$invalid = true;

		}
		//Name Validation
		//Cannot contain numbers
		if(!preg_match("/^[a-zA-Z]*$/", $name)){
			$name_err = "Name can only contain letters.";
			$invalid = true;

		}

		


	}



	//creating the query to insert a new account into the database
	$sql = "INSERT INTO account (email,name,password) VALUES ('$email', '$name', sha1('$password'))";

	//running the query once the submit button is pressed
	if(isset($_POST['submit']) && $invalid===false){
		mysqli_query($conn, $sql);
		header("location:register_v4.php");
	}
	
	
	//close the connection
	mysqli_close($conn);
	?>
	
	
	<div style="color:red; text-align:center;">
		<?php echo $password_length_err; ?> <br>
		<?php echo $password_number_err; ?> <br>
		<?php echo $password_capital_err; ?> <br>
		<?php echo $email_err; ?> <br>
		<?php echo $name_err; ?>
	</div>


</body>

</html>