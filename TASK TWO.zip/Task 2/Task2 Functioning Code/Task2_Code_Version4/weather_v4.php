
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php
	//opens session
		session_start();
		
	?>

	<!-- single stylsheet for all pages -->
	<link rel="stylesheet" href="stylesheet_v4.css">
	
	<!-- website header above navbar-->
	<h1 class="name">Health Advice Group</h1>

	<!-- tab title -->
	<title>Health Advice Group | Location</title>
</head>
<body id="Mode">

	<!-- navbar links -->
	<nav class="navbar">
		<ul>
			<li><a href="dashboard_v4.html">Home</a></li>
			<li><a href="weather_v4.php" class="active">Weather</a></li>
			<li><a href="advice_v4.html">Advice</a></li>
			<li><a href="account_v4.php">Account</a></li>
			<li><a href="login_v4.php">Login</a></li>
		</ul>
	</nav>
	
	<!-- Creates a section for just the heading and the description of what the page does -->
	<section>
		<div class="text">
			<h2> Weather and Environment Data </h2>
			<p> This page provides access to up-to-date weather information and data. Select your nearest location from the available options to 
			see the current Pollen Count, Air Quality and Temperature. </p>			
			
			<p class="text-bottom">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
			sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
			Donec ac odio tempor orci dapibus. Cursus turpis massa tincidunt dui ut ornare lectus sit.
			Quis enim lobortis scelerisque fermentum dui faucibus in ornare.</p>
		
		</div>
	</section>
    
    <?php
    //Connecting to an api to use for the display of weather information.

    //Opens curl request
    $ch = curl_init();

	//Sets the value of location by default to London
    $location = "latitude=51.51&longitude=-0.13";

    if(isset($_POST['location'])){
        $location = $_POST['location'];
    }
           

    //sets the url to get temperature reading
    curl_setopt($ch, CURLOPT_URL, "https://api.open-meteo.com/v1/forecast?".$location."&hourly=temperature_2m");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    //decodes the json response
    $data = json_decode($response, true);

    //pulls the data from the api from the earliest recording, and assigns this value to 'temp'
    $temp = "";
    $temp = $data["hourly"]["temperature_2m"][0];

    //sets url to air quality reading and pollen count
    curl_setopt($ch, CURLOPT_URL, "https://air-quality-api.open-meteo.com/v1/air-quality?".$location."&hourly=alder_pollen,birch_pollen,grass_pollen,european_aqi");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    //decodes json response
    $data = json_decode($response, true);

    //assigns the pollen and air quality values to variables that are then referenced in the page.
    $pollen = $aqi = "";

    //'0' is used for the index in order to pull the earliest recorded value
	$b_pollen = $data["hourly"]["birch_pollen"][0];
	$a_pollen = $data["hourly"]["alder_pollen"][0];
    $g_pollen = $data["hourly"]["grass_pollen"][0];
    $aqi = $data["hourly"]["european_aqi"][0];

    ?>

	<!-- divides the page into two halves, one half for weather info (temperature, air quality and pollen) 
	and one for information sources -->
		<aside class="left">
			<h3> Weather Information </h3>
            <form method="POST" action="weather_v4.php" name="form">
                <select class="dropdown" name="location">
                    <option name="London" value="latitude=51.51&longitude=-0.13" selected>London</option> 
                    <option name="Manchester" value="latitude=53.48&longitude=-2.24">Manchester</option>
                    <option name="Birmingham" value="latitude=52.48&longitude=-1.90">Birmingham</option>
                    <option name="Basildon" value="latitude=51.57&longitude=0.46">Basildon</option>
                </select>
                <input name="submit" type="submit">
            </form>
			
			<!-- pollen count for information -->
			<h4> Alder Pollen Count: <?php echo $a_pollen; ?> </h4>
			<h4> Birch Pollen Count: <?php echo $b_pollen; ?> </h4>
			<h4> Grass Pollen Count: <?php echo $g_pollen; ?> </h4>
            <!-- api percentage is inverted so that it displays as how pure the air is, rather than how polluted -->
			<h4> Air Quality: <?php echo (100-$aqi); ?>% </h4>
			<h4> Temperature: <?php echo $temp; ?> °C</h4>
	
		</aside>
		
		<aside class="right">
			<h3> Additional Information </h3>
			<p> Some additional sources where you can find up to date information: </p>
			
			<!-- these image boxes make sure that the images scale on other screen sizes -->
			<div class="imagebox">
				<li> <a href="https://www.metoffice.gov.uk/weather/forecast/uk"> <img src="../images/met-office.png" alt="Met Office logo"></a></li>
				
			</div>
			
			<div class="imagebox">
				<li> <a href="https://www.bbc.co.uk/weather"> <img src="../images/bbc-weather.png" alt="BBC Weather logo"></a></li>
			</div>
			
			<div class="imagebox">
				<li> <a href="https://uk-air.defra.gov.uk/air-pollution/daqi?view=more-info&pollutant=pm25#:~:text=The%20DAQI%20tells%20you%20about%20levels%20of%20air,about%20air%20pollution%20levels%20in%20a%20simple%20way"> <img src="../images/defra-logo.png" alt="Defra logo"></a></li>
			</div>
		</aside>
	
	
</body>

</html>