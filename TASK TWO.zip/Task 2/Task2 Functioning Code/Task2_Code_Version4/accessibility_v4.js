
//Creating a function that sets the current mode to whatever has been last pressed.
function mode_select(){
	let mode = localStorage.getItem("mode");
	let font = localStorage.getItem("font");
	
	if (mode === "Dark"){
		D_Mode();
		
	}
	else{
		L_Mode();
		
	}
	
	if (font === "Small"){
		S_font();
	}
	else if (font === "Large"){
		L_font();
	}
}

//changes the font size between small and large
function S_font(){
	localStorage.setItem("font", "Small");
	document.getElementById("Font").style = ("font-size:11px;");
	
}

function L_font(){
	localStorage.setItem("font", "Large");
	document.getElementById("Font").style = ("font-size:30px;");
	
}

//Light Mode, clears localstorage to avoid errors and sets the value of "mode" as "Light"
function L_Mode(){
	document.getElementById("Mode").style = ("background-color: white; color:black;");
	localStorage.setItem("mode", "Light");
}

//Dark Mode, same as above but instead for dark
function D_Mode(){
	document.getElementById("Mode").style = ("background-color: black; color:white;");
	localStorage.setItem("mode", "Dark");
}



