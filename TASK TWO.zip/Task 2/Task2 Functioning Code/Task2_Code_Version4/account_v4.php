<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php
	//opens session
		session_start();
		
		//checks if user is logged in. If not, visit login page to sign in
		if(!isset($_SESSION['loggedin'])){
			header('location: login_v4.php');
			
		}
	?>
	<!-- link to stylesheet -->
	<link rel="stylesheet" href="stylesheet_v4.css">
	
	<h1 class="name">Health Advice Group</h1>
	
	<!-- tab title -->
	<title>Health Advice Group | Account</title>
</head>

<!-- id of 'mode' given for planned light and dark mode (unfinished) -->
<body style="height:100vh" id="Mode" onload="mode_select()">
	<!-- navbar -->
	<nav class="navbar">
		<ul>
			<li><a href="dashboard_v4.html">Home</a></li>
			<li><a href="weather_v4.php">Weather</a></li>
			<li><a href="advice_v4.html">Advice</a></li>
			<li><a href="account_v4.php" class="active">Account</a></li>
			<li><a href="login_v4.php">Login</a></li>
		</ul>
	</nav>
	
	<?php
		//connecting to database
		require_once("db_connect_v4.php");
		
		//taking logged in user information
		$name = $_SESSION['user']['name'];
		$email = $_SESSION['user']['email'];
	 
	?>
	<!-- shows account details for users who are logged in -->
	<aside class="left">
		<div style="margin-left:2vw;"class="account">
			<h2> Account Details </h2>
			<p> First Name: <?php echo $name; ?> </p>
			<p> Email: <?php echo $email; ?> </p> <br>
			
			<!-- Interactive Accessibility features to change basic settings of the website -->
			<h2> Accessibility Features </h2>
			
			<!-- connects to light and dark mode file, using two buttons -->
			<input type="button" onclick="L_Mode()" value="Light Mode">
			<input type="button" onclick="D_Mode()" value="Dark Mode"> <br>
			
			<p style="margin-top: 1vw; margin-left:0;"> Font Sizes </p>
			<input type="button" onclick="L_font()" value="Large">
			<input type="button" onclick="S_font()" value="Small">
			<p id="Font" style="margin-top: 1vw; margin-left:0;"> Sample Text </p>
			<script src="accessibility_v4.js"></script>
		</div>
	</aside>
	
	<!-- right side of the page includes exercise tracker -->
	<aside class="right">
		<!-- id of 'mode' given to work with dark and light mode features (unfinished) -->
		<div id="Mode" style="margin-left:2vw;" class="account">
			<h2> Exercise Tracker </h2>
			<p> Enter the total number of hours of exercise you have completed this week. This website will
			respond with how close you are to the recommended amount of exercise. 
			
			If you did not exercise on a given day, please enter '0'.
			</p>
			
			<!-- form to allow users to enter their exercise per day this week -->
			<!-- these fields are required so that the user must enter a number for each of them. Even if they are empty, since all are taken
			they must be filled with either a number or a zero. -->
			<form name="hours" action="account_v4.php" method="post">
				<label>Monday:    </label><input type="number" step="0.5" name="Monday" placeholder="Exercise in hours" required></input> <br>
				<label>Tuesday:   </label><input type="number" step="0.5" name="Tuesday" placeholder="Exercise in hours" required></input> <br>
				<label>Wednesday: </label><input type="number" step="0.5" name="Wednesday" placeholder="Exercise in hours" required></input> <br>
				<label>Thursday:  </label><input type="number" step="0.5" name="Thursday" placeholder="Exercise in hours" required></input> <br>
				<label>Friday:    </label><input type="number" step="0.5" name="Friday" placeholder="Exercise in hours" required></input> <br>
				<label>Saturday:  </label><input type="number" step="0.5" name="Saturday" placeholder="Exercise in hours" required></input> <br>
				<label>Sunday:    </label><input type="number" step="0.5" name="Sunday" placeholder="Exercise in hours" required></input> <br>
				<input type="submit" name="submit" value="Submit">
			</form>
			
			<?php
				//2.5 is the recommended hours of moderate exercise a week for an adult
				//future editions and improvements can be made to adjust this value e.g. for children, vigorous exercise etc
				$exercise = 2.5;
			
				
				//post request for the data that has been submitted
				if($_SERVER["REQUEST_METHOD"] == "POST"){
					$mon = $_POST["Monday"];
					$tues = $_POST["Tuesday"];
					$wed = $_POST["Wednesday"];
					$thurs = $_POST["Thursday"];
					$fri = $_POST["Friday"];
					$sat = $_POST["Saturday"];
					$sun = $_POST["Sunday"];
					
					//adds all values
					$total = $mon + $tues + $wed + $thurs + $fri;
					
					
					//checks if the total is either greater or lower than the recommended
					if ($total < $exercise){
						$diff = $exercise - $total;
						$output = "You are ".$diff." hour(s) away from the recommended weekly amount.";
						
					}
					else if ($total >= $exercise){
						$diff = $total - $exercise;
						$output = "You are ".$diff." hour(s) above the recommended weekly amount.";
					}
					
					//tells users their total and if it is above or below the recommended
					echo nl2br("You have exercised for a total of ".$total." hour(s) this week.\n ".$output);
					
					
				}
			
			?>
			
		</div>
	</aside>
</body>

</html>