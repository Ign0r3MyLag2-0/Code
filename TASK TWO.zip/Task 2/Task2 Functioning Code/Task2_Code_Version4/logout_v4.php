<!DOCTYPE HTML>
<html lang="en">
<head>
	<?php
	//unsets the session and destroys it, before returning to login page.
		session_start();
		unset($S_SESSION);
		session_destroy();
		$_SESSION['loggedin'] = false;
		
		header('location: login_v4.php');
		
		
	?>
	
</head>
</html>

