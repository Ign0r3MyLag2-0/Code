<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php
		//opens session to stop errors
		session_start();

	?>

	<!-- link to stylesheet -->
	<link rel="stylesheet" href="stylesheet_v4.css">
	
	<h1 class="name">Health Advice Group</h1>
	
	<!-- tab title -->
	<title>Health Advice Group | Login</title>
</head>

<!-- id given as 'mode' for light and dark mode (unfinished) -->
<body style="height:100vh" id="Mode" onload="mode_select()">
	<!-- navbar styling -->
	<nav class="navbar">
		<ul>
			<li><a href="dashboard_v4.html">Home</a></li>
			<li><a href="weather_v4.php">Weather</a></li>
			<li><a href="advice_v4.html">Advice</a></li>
			<li><a href="account_v4.php">Account</a></li>
			<li><a href="login_v4.php" class="active">Login</a></li>
		</ul>
	</nav>
	
	
	<!-- login form to allow users to enter their information -->
	<!-- 'mode' is given as id for light and dark mode (unfinished) -->
	<div id="Mode" class="login-form">
		<h2> LOGIN </h2>
		<form action="login_v4.php" method="post">
			<input class="input" type="text" placeholder="Email Address" name="email" required></input> <br>
			<input class="input" type="text" placeholder="Password" name="password" required></input> <br>
			<input class="submit" type="submit" name="submit" value="Login"></input>
		</form>
		<!-- lets user redirect to register page to create an account -->
		<p> Not a user? <a href="register_v4.php">Sign Up</a> </p>
		<button class="logout"><a style="text-decoration:none; color:black;" href="logout_v4.php">Logout</button></a>
	</div>
	
	<?php
	//connecting to database
	require_once("db_connect_v4.php");
	
	
	global $hashed_password;
	//testing inputs to prevent SQL injection
	function test_inputs($input){
		global $conn;
		//trims whitespace on either side of string
		$input = trim($input);
		//gets rid of backslashes
		$input = stripslashes($input);
		//takes any symbols that correspond to html markup and recognises it as normal text
		$input = htmlspecialchars($input);
		//any remaining special characters are not considered as part of a query
		return mysqli_real_escape_string($conn, $input);
	}

	//if user is not logged in, message is blank
	if(!isset($_SESSION['loggedin'])){
			$response = "";
			
	}
	//displays login message
	else{
		$response = "Currently logged in as ".$_SESSION['user']['name'];
	}

	//storing entered data as variables
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$email = test_inputs($_POST['email']);
		$password = test_inputs($_POST['password']);
		//hashes password 
		$password = sha1($password);
		
		
		//Once account details have been taken, uses this query that the correct email and password
		//has been entered, and that the details correspond to one another.
		if($result = $conn->query("SELECT * FROM account WHERE email = '$email' AND password = '$password';")){
			if($row = $result->fetch_assoc()){
				$_SESSION['user'] = $row;
				//sets logged in to true, so user can now access account page
				$_SESSION['loggedin'] = true;
				$response = "Successfully logged in as ".$_SESSION['user']['name'];
				
				
			}
			
		}
	
	}
	

	?>
	<!-- login message -->
	<div class="message" style="text-align:center; color:teal;">
		<?php echo $response;?>
		
	</div>
	
	
</body>

</html>