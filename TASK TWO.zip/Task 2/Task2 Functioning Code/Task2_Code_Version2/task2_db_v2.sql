
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: `task2_db`
--

-- --------------------------------------------------------

--
-- Table structure for account table
-- four fields: account_id (Primary Key), email, name and password

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `email` text DEFAULT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for account table
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`);



-- Setting auto increment for account_id

ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

-- Creating a default user for the accounts

INSERT INTO `account` (email,name,password) VALUES ('bob@test.com','bob','bobbers');